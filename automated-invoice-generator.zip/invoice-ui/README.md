# Invoice UI (Angular minimal via Vite)

## Run
```bash
npm install
npm run start
```
Open http://localhost:5173 and ensure the Spring Boot backend runs on http://localhost:8080

Features:
- Create clients
- Create invoices with multiple line items
- View list of invoices
- Download invoice PDF
